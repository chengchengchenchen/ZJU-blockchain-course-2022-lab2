import { HardhatUserConfig } from "hardhat/config";
import "@nomicfoundation/hardhat-toolbox";

const config: HardhatUserConfig = {
  solidity: "0.8.9",
  networks: {
    ganache: {
      // rpc url, change it according to your ganache configuration
      url: 'http://localhost:8545',
      // the private key of signers, change it according to your ganache user
      accounts: [
          '00779ecccef6788560ea8f00f609a3be61807b8996228fbab26453a5e5f71661',
          '47fd77bea5652b8e2b21afd9f24741596450dde9da7e9efd25ed8027ef0f6858',
          '2d6159206caf1c2c4feb15b36b36c32bdef9b8df5e2ca2e33669db96b5d85cbd',
          '1a8fae363da84bf15e67f8bcd21d2efc1f0fa098dad7042e107a426028a5e2df'
      ]
    },
    },
    paths: {
        sources: "./contracts",
        tests: "./test",
        cache: "./cache",
        artifacts: "./artifacts"
    },
};

export default config;
